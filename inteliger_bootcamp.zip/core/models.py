from django.db import models

# Create your models here.


class Pessoa(models.Model):
    nome = models.CharField(null=True, max_length=200)
    sexo = models.CharField(null=True, max_length=200)
    data_nascimento = models.DateField(null=True)

    class Meta:
        db_table = 'pessoas'
