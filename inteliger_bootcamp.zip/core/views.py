from django.shortcuts import render
from django.views import View


# Create your views here.
class ProvaPythonView(View):
    def get(self, *args, **kwargs):
        contexto = {}
        # tarefa 1
        # criar uma variavel LISTA_NUMEROS_ALEATORIOS com 100 números inteiros entre 1 e 9
        # atribuir essa varivel ao contexto com a chave LISTA_NUMEROS_ALEATORIOS



        # tarefa 2
        # criar uma variavel com a soma dos números da variavel LISTA_NUMEROS_ALEATORIOS
        # atribuir essa varivel ao contexto com a chave soma




        # tarefa 3
        # criar uma variavel numeros_em_ordem_crescente, atribuir a ela a copia LISTA_NUMEROS_ALEATORIOS
        # e ordenar em ordem CRESCENTE e remover a duplicidade
        # atribuir essa varivel ao contexto com a chave numeros_em_ordem_crescente




        # tarefa 4
        # criar uma variavel numeros_em_ordem_decrescente, atribuir a ela a copia LISTA_NUMEROS_ALEATORIOS
        # e ordenar em ordem DECRESCENTE e remover a duplicidade
        # atribuir essa varivel ao contexto com a chave numeros_em_ordem_decrescente





        # tarefa 5
        # fazer um filtro na variavel ListaPessoas com idade menor que 18,
        # e atribuir os dicionarios filtrados em uma nova varivel e
        # atribuir essa varivel ao contexto com a chave lista_pessoas_menor_de_idade
        ListaPessoas = [
            {'nome': 'Maria', 'idade': 20},
            {'nome': 'João', 'idade': 5},
            {'nome': 'Jose', 'idade': 60},
            {'nome': 'Bruna', 'idade': 20},
            {'nome': 'Lara', 'idade': 10},
        ]



        return render(self.request, template_name='core/index.html', context=contexto)


class PessoaView(View):
    def get(self, *args, **kwargs):
        # terefa 6
        contexto = {}
        contexto['pessoas'] = []
        # sobrescrerver a variavel contexto['pessoas'] com uma lista de pessoa que vem do banco de dados
        # ja esta criado os dados no banco e a model, so preciso da query usando a orm,
        # porem preciso que seja feito um fitro de pelo sexo 'F' e ordenado pela pk.
        # se possivel usar uma funçao para nao misturar logica com a view.
        # PRECISO VER AS INFORMAÇÕES
        contexto['titulo'] = 'Lista de pessoas'
        return render(self.request, template_name='core/pessoas.html', context=contexto)


# terefa 7
# Criar uma view para buscar os nomes e siglas de estados do brasil, 
# em uma tabela nova que tem que ser criada na model.

# A view precisa ser acessada por meio de uma url chamada /estados, 
# e precisa trazer os dados do banco de dados.

# Ponto extra: Crie um html que mostre os estados em tela. 
# Não nos importamos com a beleza da tela, só de retornar a informação ja é suficiente


